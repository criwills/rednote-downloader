function downloadVideo() {
    const url = document.getElementById("videoUrl").value;
    const result = document.getElementById("result");

    if (!url.trim()) {
        result.innerHTML = "<p style='color:red;'>Masukkan URL terlebih dahulu.</p>";
        return;
    }

    // Contoh API legal untuk mengunduh konten bebas copyright
    // const api = `https://your-api.com/download?url=${encodeURIComponent(url)}`;

    // SIMULASI: hasil download
    result.innerHTML = `
        <div class="card">
            <p>Video siap diunduh:</p>
            <a href="#" download class="download-btn">Download Video</a>
        </div>
    `;
}

