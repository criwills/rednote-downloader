const API_BASE = ""; // bila backend di domain lain, ganti dengan https://your-backend.domain

document.getElementById("goBtn").addEventListener("click", async () => {
  const url = document.getElementById("urlInput").value.trim();
  const result = document.getElementById("result");
  const preview = document.getElementById("preview");
  result.innerHTML = "";
  preview.innerHTML = "";

  if (!url) {
    result.textContent = "Masukkan URL Douyin terlebih dahulu.";
    return;
  }

  result.textContent = "Memproses...";

  try {
    const resp = await fetch(`${API_BASE}/api/download`, {
      method: "POST",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify({ url })
    });
    const data = await resp.json();
    if (!data.ok) {
      result.textContent = "Gagal: " + (data.error || "Unknown");
      return;
    }

    const videoUrl = data.videoUrl;
    const proxyUrl = `${API_BASE}/api/proxy?videoUrl=${encodeURIComponent(videoUrl)}`;

    preview.innerHTML = `<video controls src="${proxyUrl}"></video>`;
    result.innerHTML = `
      <p>Video URL ditemukan:</p>
      <a class="download" href="${proxyUrl}" target="_blank" rel="noopener">Download Video (via proxy)</a>
      <a style="margin-left:8px" href="${videoUrl}" target="_blank" rel="noopener">Buka langsung (bisa CORS)</a>
      <p style="font-size:12px;color:#666;margin-top:8px">Jika proxy lambat, buka link langsung.</p>
    `;
  } catch (err) {
    console.error(err);
    result.textContent = "Error proses: " + err.message;
  }
});

