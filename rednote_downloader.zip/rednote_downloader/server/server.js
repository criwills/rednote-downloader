import express from "express";
import fetch from "node-fetch";
import cors from "cors";
import { pipeline } from "stream";
import { promisify } from "util";

const app = express();
app.use(cors());
app.use(express.json());
const streamPipeline = promisify(pipeline);

async function fetchText(url, headers = {}) {
  const res = await fetch(url, { headers, redirect: "follow" });
  if (!res.ok) throw new Error(`Fetch failed: ${res.status}`);
  return await res.text();
}

function extractVideoUrlFromHtml(html) {
  // Common patterns in Douyin page JSON
  const patterns = [
    /"playAddr":\s*\{"url_list":\s*\[([^\]]+)\]/i,
    /"downloadAddr":\s*\{"url_list":\s*\[([^\]]+)\]/i,
    /"play_addr":\s*\{"url_list":\s*\[([^\]]+)\]/i
  ];

  for (const p of patterns) {
    const m = html.match(p);
    if (m && m[1]) {
      const urlMatch = m[1].match(/"(https?:\\\/\\\/[^"]+)"/) || m[1].match(/"(https?:\/\/[^"]+)"/);
      if (urlMatch) return urlMatch[1].replace(/\\\//g, "/");
    }
  }

  // fallback: try to find any .mp4 url
  const mp4 = html.match(/https?:\/\/[^\s'"]+\.mp4[^\s'"]*/i);
  if (mp4) return mp4[0];

  return null;
}

app.post("/api/download", async (req, res) => {
  try {
    const { url } = req.body;
    if (!url) return res.status(400).json({ ok: false, error: "Missing url" });

    const headers = {
      "User-Agent":
        "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/124 Safari/537.36",
      Accept: "text/html"
    };

    const html = await fetchText(url, headers);
    const videoUrl = extractVideoUrlFromHtml(html);

    if (!videoUrl) {
      return res.status(500).json({ ok: false, error: "Tidak dapat mengekstrak video URL. Struktur halaman mungkin berubah." });
    }

    return res.json({ ok: true, videoUrl });
  } catch (err) {
    console.error(err);
    return res.status(500).json({ ok: false, error: err.message || "Unexpected error" });
  }
});

app.get("/api/proxy", async (req, res) => {
  try {
    const { videoUrl } = req.query;
    if (!videoUrl) return res.status(400).send("Missing videoUrl");
    if (!/^https?:\/\//i.test(videoUrl)) return res.status(400).send("Invalid URL");

    const upstream = await fetch(videoUrl, {
      headers: { "User-Agent": "Mozilla/5.0", Accept: "*/*" },
      redirect: "follow"
    });

    if (!upstream.ok) return res.status(502).send("Upstream fetch failed");
    const contentType = upstream.headers.get("content-type");
    if (contentType) res.setHeader("Content-Type", contentType);
    const contentLength = upstream.headers.get("content-length");
    if (contentLength) res.setHeader("Content-Length", contentLength);

    await streamPipeline(upstream.body, res);
  } catch (err) {
    console.error("Proxy error", err);
    if (!res.headersSent) res.status(500).send("Proxy error");
  }
});

const PORT = process.env.PORT || 3000;
app.listen(PORT, () => console.log(`RedNote server listening on ${PORT}`));

